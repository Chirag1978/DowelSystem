export const monthsOptions = [
    {text: '01 - Jan', value: '1'},
	{text: '02 - Feb', value: '2'},
	{text: '03 - Mar', value: '3'},
	{text: '04 - Apr', value: '4'},
	{text: '05 - May', value: '5'},
	{text: '06 - Jun', value: '6'},
	{text: '07 - Jul', value: '7'},
	{text: '08 - Aug', value: '8'},
	{text: '09 - Sep', value: '9'},
	{text: '10 - Oct', value: '10'},
	{text: '11 - Nov', value: '11'},
	{text: '12 - Dec', value: '12'},
]