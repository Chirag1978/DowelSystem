export const countryOptions = [
    {text: 'United States', value: 'US'},
	{text: 'United States Territories', value: 'US'},
    {text: 'Canada', value: 'CN'}
]
